#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include <webots/robot.h>
#include <webots/motor.h>
#include <webots/lidar.h>
#include <webots/compass.h>

#define MAX_SPEED 6.28/6
#define PI 3.141592654

double get_bearing_in_degrees(WbDeviceTag my_compass);
double get_range(WbDeviceTag my_lidar);
void get_min_distance(WbDeviceTag left_motor, WbDeviceTag right_motor, WbDeviceTag my_lidar, WbDeviceTag my_compass);
void straight_wall(WbDeviceTag left_motor, WbDeviceTag right_motor, WbDeviceTag my_lidar);
void parallel_wall(WbDeviceTag left_motor, WbDeviceTag right_motor, WbDeviceTag my_compass);

int main(int argc, char **argv) {
  WbDeviceTag my_compass, my_lidar, left_motor, right_motor;
  int last_display_second = 0, time_step = 0, display_second = 0, flag = 0;

  wb_robot_init();

  my_compass = wb_robot_get_device("compass");
  my_lidar = wb_robot_get_device("hokuyo");
  left_motor = wb_robot_get_device("left wheel motor");
  right_motor = wb_robot_get_device("right wheel motor");

  wb_motor_set_position(left_motor, INFINITY);
  wb_motor_set_position(right_motor, INFINITY);
  wb_motor_set_velocity(left_motor, 0.0);
  wb_motor_set_velocity(right_motor, 0.0);
  
  wb_compass_enable(my_compass, 10);
  wb_lidar_enable(my_lidar, 10);

  time_step = (int)wb_robot_get_basic_time_step();

  while ((wb_robot_step(time_step) != -1) && flag == 0) {
    display_second = (int)wb_robot_get_time();
    
    if (display_second != last_display_second) {
      last_display_second = display_second;
    }

    get_min_distance(left_motor, right_motor, my_lidar, my_compass);
    straight_wall(left_motor, right_motor, my_lidar);
    parallel_wall(left_motor, right_motor, my_compass);

    flag = 1;
  };

  wb_robot_cleanup();

  return EXIT_SUCCESS;
}

double get_bearing_in_degrees(WbDeviceTag my_compass) {
  const double *north = wb_compass_get_values(my_compass);
  double rad = atan2(north[0], north[2]);
  double bearing = (rad - PI/2) / PI * 180.0;

  if (bearing < 0.0)
    bearing = bearing + 360.0;
 
  return bearing;
}

double get_range(WbDeviceTag my_lidar) {
  const float *image = wb_lidar_get_range_image(my_lidar);
  int resolution = round(wb_lidar_get_horizontal_resolution(my_lidar) / 2);
  
  return *(image + resolution);
}

void get_min_distance(WbDeviceTag left_motor, WbDeviceTag right_motor, WbDeviceTag my_lidar, WbDeviceTag my_compass) {
    float min_distance = wb_lidar_get_max_range(my_lidar), current_distance = 0;
    int world_init_heading = get_bearing_in_degrees(my_compass), world_current_heading = 0, robot_current_heading = 0, robot_old_heading = 0, world_min_heading = 0;
    int lap = 0, found = 0;

    wb_motor_set_velocity(right_motor, -MAX_SPEED);
    wb_motor_set_velocity(left_motor, MAX_SPEED);

    while (found == 0) {
      current_distance = get_range(my_lidar);
      world_current_heading = get_bearing_in_degrees(my_compass);
      robot_current_heading = (360 + world_current_heading - world_init_heading) % 360;

      if (min_distance > current_distance) {
        min_distance = current_distance;
        world_min_heading = world_current_heading;
      }

      if (robot_current_heading < robot_old_heading) {
        lap = 1;
        printf("Minimum distance: %f \n", min_distance);
        printf("Minimum orientation: %d \n", world_min_heading);
      }

      if (lap == 1) {
        if (world_current_heading > world_min_heading - 1 && world_current_heading < world_min_heading + 1) {
          found = 1;
        }
      }

      robot_old_heading = robot_current_heading;
      wb_robot_step(64);
    }

    wb_motor_set_velocity(left_motor, 0.0);
    wb_motor_set_velocity(right_motor, 0.0);
}

void straight_wall(WbDeviceTag left_motor, WbDeviceTag right_motor, WbDeviceTag my_lidar) {
  float current_distance = get_range(my_lidar);
  
  wb_motor_set_velocity(left_motor, MAX_SPEED*2);
  wb_motor_set_velocity(right_motor, MAX_SPEED*2);

  while (current_distance >= 0.1) {
    current_distance = get_range(my_lidar);

    wb_robot_step(64);
  }

  wb_motor_set_velocity(left_motor, 0.0);
  wb_motor_set_velocity(right_motor, 0.0);
}

void parallel_wall(WbDeviceTag left_motor, WbDeviceTag right_motor, WbDeviceTag my_compass) {
  int initial_heading = get_bearing_in_degrees(my_compass), robot_current_heading = 0, world_current_heading = get_bearing_in_degrees(my_compass);
  
  robot_current_heading = (360 + world_current_heading - initial_heading) % 360;

  while (robot_current_heading < 90) {
    world_current_heading = get_bearing_in_degrees(my_compass);
    robot_current_heading = (360 + world_current_heading - initial_heading) % 360;

    wb_motor_set_velocity(right_motor, -MAX_SPEED);
    wb_motor_set_velocity(left_motor, MAX_SPEED);

    wb_robot_step(64);
  }

  wb_motor_set_velocity(right_motor, 0.0);
  wb_motor_set_velocity(left_motor, 0.0);
}