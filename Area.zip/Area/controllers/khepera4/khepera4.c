#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include <webots/robot.h>
#include <webots/motor.h>
#include <webots/lidar.h>
#include <webots/compass.h>

#define SPEED 6.28/6 // rad/s
#define PI 3.141592654

double get_range(WbDeviceTag my_lidar, int position);
double get_bearing_in_degrees(WbDeviceTag my_compass);
bool straight_wall(WbDeviceTag left_motor, WbDeviceTag right_motor, WbDeviceTag my_lidar, WbDeviceTag my_compass);
void parallel_wall(WbDeviceTag left_motor, WbDeviceTag right_motor, WbDeviceTag my_compass);
void detectWall(WbDeviceTag left_motor, WbDeviceTag right_motor, WbDeviceTag my_lidar);
void correctDistance(WbDeviceTag left_motor, WbDeviceTag right_motor, WbDeviceTag my_lidar);
float cornerFound(WbDeviceTag left_motor, WbDeviceTag right_motor, WbDeviceTag my_lidar, float distances[4]);
float getArea(float sides[], int corners);


int main(int argc, char **argv) {
    wb_robot_init(); 

     
    //VARIABLES
    WbDeviceTag my_compass = wb_robot_get_device("compass"), my_lidar = wb_robot_get_device("hokuyo"), left_motor = wb_robot_get_device("left wheel motor"), right_motor = wb_robot_get_device("right wheel motor");
    int time_step = (int)wb_robot_get_basic_time_step();
    bool flag_1 = false, finished = false;
    int world_current_heading = 0, robot_current_heading = 0, world_init_heading = 0;
    int corners = 0;
    float distances[4] = {0, 0, 0, 0};

    //MOTOR CONFIGURATION
    wb_motor_set_position(left_motor, INFINITY);
    wb_motor_set_position(right_motor, INFINITY);
    wb_motor_set_velocity(left_motor, 0.0);
    wb_motor_set_velocity(right_motor, 0.0);

    //ENABLES
    wb_compass_enable(my_compass, 10);
    wb_lidar_enable(my_lidar, 10);
    
    //PRINCIPAL WHILE
    while (wb_robot_step(time_step) != -1 && finished == false) {
        if (flag_1 == false) {
            flag_1 = straight_wall(left_motor, right_motor, my_lidar, my_compass);//finds a wall and sets its position 
        } else {
            detectWall(left_motor, right_motor, my_lidar); //walks along a wall and stops when it finds another

            if (corners == 0) {
                world_init_heading = get_bearing_in_degrees(my_compass); //gets initial heading
            }

            wb_robot_step(32);

            world_current_heading = get_bearing_in_degrees(my_compass); 
            robot_current_heading = (360 + world_current_heading - world_init_heading) % 360;
           
            if (robot_current_heading > 330) { //it has turned 360 aprox-> finished
                finished = true;
                wb_motor_set_velocity(right_motor, 0.0);
                wb_motor_set_velocity(left_motor, 0.0);
                printf("Area: %f \n", getArea(distances, corners));
            } else {
                wb_robot_step(64);
                distances[corners] = cornerFound(left_motor, right_motor, my_lidar, distances) + 0.15;
                corners++;
            }
        }
        
        wb_robot_step(64);
    }

    wb_robot_cleanup();

    return EXIT_SUCCESS;
}

double get_range(WbDeviceTag my_lidar, int position) {
    const float *image = wb_lidar_get_range_image(my_lidar);
    
    return *(image + position);
}

double get_bearing_in_degrees(WbDeviceTag my_compass) {
    const double *north = wb_compass_get_values(my_compass);
    double rad = atan2(north[0], north[2]);
    double bearing = (rad - PI/2) / PI * 180.0;

    if (bearing < 0.0)
        bearing = bearing + 360.0;

    return bearing;
}

bool straight_wall(WbDeviceTag left_motor, WbDeviceTag right_motor, WbDeviceTag my_lidar, WbDeviceTag my_compass) {
    int mid_pos = round(wb_lidar_get_horizontal_resolution(my_lidar) / 2);

    float mid_distance = get_range(my_lidar, mid_pos);
    float left_distance = get_range(my_lidar, mid_pos - 10);
    float right_distance = get_range(my_lidar, mid_pos + 10);

    if (left_distance >= mid_distance && right_distance >= mid_distance) {
        mid_distance = get_range(my_lidar, mid_pos);

        wb_motor_set_velocity(left_motor, SPEED*2);
        wb_motor_set_velocity(right_motor, SPEED*2);

        while (mid_distance >= 0.1) {
            mid_distance = get_range(my_lidar, mid_pos);

            wb_robot_step(64);
        }

        parallel_wall(left_motor, right_motor, my_compass);

        return true;
    } else {
        wb_motor_set_velocity(right_motor, -SPEED);
        wb_motor_set_velocity(left_motor, SPEED);

        return false;
    }
}

void parallel_wall(WbDeviceTag left_motor, WbDeviceTag right_motor, WbDeviceTag my_compass) {
    int initial_heading = get_bearing_in_degrees(my_compass), robot_current_heading = 0, world_current_heading = get_bearing_in_degrees(my_compass);

    robot_current_heading = (360 + world_current_heading - initial_heading) % 360;

    while (robot_current_heading < 90) {
        world_current_heading = get_bearing_in_degrees(my_compass);
        robot_current_heading = (360 + world_current_heading - initial_heading) % 360;

        wb_motor_set_velocity(right_motor, -SPEED);
        wb_motor_set_velocity(left_motor, SPEED);

        wb_robot_step(64);
    }

    wb_motor_set_velocity(right_motor, 0.0);
    wb_motor_set_velocity(left_motor, 0.0);
}

void detectWall(WbDeviceTag left_motor, WbDeviceTag right_motor, WbDeviceTag my_lidar) {
    float straight_distance = get_range(my_lidar, round(wb_lidar_get_horizontal_resolution(my_lidar) / 2));
    float right_distance = get_range(my_lidar, round(wb_lidar_get_horizontal_resolution(my_lidar) * 3 / 4));

    while (straight_distance >= 0.1 && right_distance >= 0.1) {//while it doesnt find a wall it keeps moving
        straight_distance = get_range(my_lidar, round(wb_lidar_get_horizontal_resolution(my_lidar) / 2));
        right_distance = get_range(my_lidar, round(wb_lidar_get_horizontal_resolution(my_lidar) * 3 / 4));
        wb_motor_set_velocity(right_motor, SPEED);
        wb_motor_set_velocity(left_motor, SPEED);

        wb_robot_step(32);

        correctDistance(left_motor, right_motor, my_lidar); //and the trajectory is corrected
    }

    wb_motor_set_velocity(right_motor, 0.0);
    wb_motor_set_velocity(left_motor, 0.0);
}

void correctDistance(WbDeviceTag left_motor, WbDeviceTag right_motor, WbDeviceTag my_lidar) {
    float distance = get_range(my_lidar, round(wb_lidar_get_horizontal_resolution(my_lidar) / 8));
    
    if (distance < 0.0995) {
        wb_robot_step(32);
        wb_motor_set_velocity(right_motor, -SPEED/6);
        wb_motor_set_velocity(left_motor, SPEED/6);
    } else if (distance > 0.105) {
        wb_robot_step(32);
        wb_motor_set_velocity(right_motor, SPEED/6);
        wb_motor_set_velocity(left_motor, -SPEED/6);
    }

    wb_robot_step(32);
}

float cornerFound(WbDeviceTag left_motor, WbDeviceTag right_motor, WbDeviceTag my_lidar, float distances[4]) {
    float straight_distance = get_range(my_lidar, round(wb_lidar_get_horizontal_resolution(my_lidar) / 2));
    float distance = get_range(my_lidar, round(wb_lidar_get_horizontal_resolution(my_lidar) / 8));

    while ((distance >= 0.0995 && distance < 0.105) || straight_distance <= 0.7) {
        straight_distance = get_range(my_lidar, round(wb_lidar_get_horizontal_resolution(my_lidar) / 2));
        distance = get_range(my_lidar, round(wb_lidar_get_horizontal_resolution(my_lidar) / 8));

        wb_robot_step(32);
        wb_motor_set_velocity(right_motor, -SPEED);
        wb_motor_set_velocity(left_motor, SPEED);
    }

    return get_range(my_lidar, round(wb_lidar_get_horizontal_resolution(my_lidar) / 2));
}

float getArea(float side[], int corners){
    float area = 0, S = 0;

    if (corners==3){
            S = (side[0]+side[1]+side[2])/2;
            area = sqrt(S*(S-side[0])*(S-side[1])*(S-side[2]));//Juanito Formula
    }else if (corners == 4){
            area = side[0]*side[1];
    }
    return area;
}
